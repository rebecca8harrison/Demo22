## The Developer Academy

### Advanced - Spark

- [python/spark_intro](python/spark_intro) - a collection of walkthroughs for the three main Spark abstractions - RDD, SQL, MLLIB
- [phase_2](phase_2) - dataset for MLLIB exercise

